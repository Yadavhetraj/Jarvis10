"""Adds the permissions and package-visibility entries Jarvis needs to the
generated AndroidManifest.xml (mic, internet, speech + TTS services)."""
import pathlib
import sys

path = pathlib.Path("android/app/src/main/AndroidManifest.xml")
text = path.read_text(encoding="utf-8")

if "RECORD_AUDIO" in text:
    print("Manifest already patched")
    sys.exit(0)

permissions = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.BLUETOOTH"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
"""

queries = """    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="https"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.MAIN"/>
        </intent>
    </queries>
"""

marker = "<application"
if marker not in text:
    sys.exit("Could not find <application> in AndroidManifest.xml")

text = text.replace(marker, permissions + queries + "    " + marker, 1)
text = text.replace('android:label="jarvis_ai"', 'android:label="Jarvis"', 1)
path.write_text(text, encoding="utf-8")
print("Manifest patched")
