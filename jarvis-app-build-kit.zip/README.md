# Jarvis AI – Android app (build kit)

This is the Flutter source from `Aryan-0001/Jarvis-AI` wrapped so GitHub builds the APK for you.
Nothing needs to be installed on your computer.

## Get the APK

1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Get a free Gemini API key from https://aistudio.google.com/apikey
3. In your repo: **Settings → Secrets and variables → Actions**
   - Secrets tab → **New repository secret** → name `GEMINI_API_KEY`, value = your key.
   - (Optional) Variables tab → **New repository variable** → name `GEMINI_MODEL` if you want a model other than `gemini-2.5-flash`.
4. Open the **Actions** tab → **Build Jarvis APK** → **Run workflow**.
5. When it finishes (about 5–10 minutes), open the run and download the **jarvis-apk** artifact. Unzip it to get `app-release.apk`.
6. Copy the APK to your phone and install it (allow "install unknown apps" when asked).

## Notes

- The API key is baked into the APK, so keep the APK for personal use only.
- Startup sounds are optional: put `startup.mp3` and `wake.mp3` in `assets/sounds/` to enable them.
- The app was assembled without being compiled here. If the build fails, open the failed step in the Actions log and send me the error.
